# Library Management System

class Book:
    def __init__(self, id, title, author, genre, isbn):
        self.id = id
        self.title = title
        self.author = author
        self.genre = genre
        self.isbn = isbn
        self.available = True

class Library:
    def __init__(self):
        self.books = []
        self.next_id = 1

    def add_book(self, title, author, genre, isbn):
        book = Book(self.next_id, title, author, genre, isbn)
        self.books.append(book)
        self.next_id += 1
        print(f"Book '{title}' added successfully!")

    def list_books(self):
        print("\nLibrary Book List:")
        if not self.books:
            print("No books in the library.")
            return
        for book in self.books:
            status = "Available" if book.available else "Borrowed"
            print(f"{book.id}. {book.title} by {book.author} ({book.genre}) [ISBN: {book.isbn}] - {status}")

    def borrow_book(self, book_id):
        for book in self.books:
            if book.id == book_id:
                if book.available:
                    book.available = False
                    print(f"You borrowed '{book.title}'.")
                else:
                    print("Book is already borrowed.")
                return
        print("Book ID not found.")

    def return_book(self, book_id):
        for book in self.books:
            if book.id == book_id:
                if not book.available:
                    book.available = True
                    print(f"You returned '{book.title}'.")
                else:
                    print("Book was not borrowed.")
                return
        print("Book ID not found.")

    def delete_book(self, book_id):
        for book in self.books:
            if book.id == book_id:
                self.books.remove(book)
                print(f"Book '{book.title}' deleted.")
                return
        print("Book ID not found.")

def main():
    library = Library()

    while True:
        print("\nLibrary Management System")
        print("1. Add Book")
        print("2. List Books")
        print("3. Borrow Book")
        print("4. Return Book")
        print("5. Delete Book")
        print("6. Exit")

        choice = input("Enter choice: ")

        if choice == '1':
            title = input("Enter book title: ")
            author = input("Enter author: ")
            genre = input("Enter genre: ")
            isbn = input("Enter ISBN: ")
            library.add_book(title, author, genre, isbn)
        elif choice == '2':
            library.list_books()
        elif choice == '3':
            try:
                book_id = int(input("Enter book ID to borrow: "))
                library.borrow_book(book_id)
            except ValueError:
                print("Invalid input. Enter a number.")
        elif choice == '4':
            try:
                book_id = int(input("Enter book ID to return: "))
                library.return_book(book_id)
            except ValueError:
                print("Invalid input. Enter a number.")
        elif choice == '5':
            try:
                book_id = int(input("Enter book ID to delete: "))
                library.delete_book(book_id)
            except ValueError:
                print("Invalid input. Enter a number.")
        elif choice == '6':
            print("Exiting the Library Management System. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()